# Changelog

## 2025-11-15T14:28:46.954666

- Initial profile scaffolding created (identity, professional projects, personal projects, EVA architecture, preferences, values, workflows).
- Added `prompts_playbook.json` with common/ideal prompt patterns for Marco.
- Added `meeting_summaries/meeting_summary_template.json` to standardize how key meetings are captured for AI/context reuse.
